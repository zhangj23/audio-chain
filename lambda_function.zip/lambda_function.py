"""
AWS Lambda function for Weave video compilation (Simplified Version)
Processes weekly video submissions and creates compilations
Uses S3 for data storage instead of PostgreSQL
"""

import json
import os
import boto3
import subprocess
import tempfile
from datetime import datetime, timedelta
from typing import List, Dict, Any

# AWS Configuration
S3_BUCKET = os.environ.get('S3_BUCKET', 'weave-videos')
AWS_REGION = os.environ.get('AWS_REGION', 'us-east-1')  # Automatically provided by Lambda

# Initialize AWS clients
s3_client = boto3.client('s3', region_name=AWS_REGION)

def lambda_handler(event, context):
    """
    Main Lambda handler for video compilation
    """
    try:
        print("🎬 Starting Weave video compilation...")
        print(f"Region: {context.invoked_function_arn.split(':')[3]}")
        
        # Test FFmpeg availability
        try:
            result = subprocess.run(['/opt/bin/ffmpeg', '-version'], capture_output=True, text=True)
            if result.returncode == 0:
                print("✅ FFmpeg layer is available")
            else:
                print("❌ FFmpeg layer not found, trying system FFmpeg")
        except Exception as e:
            print(f"⚠️ FFmpeg test failed: {e}")
        
        # Determine FFmpeg path
        ffmpeg_path = '/opt/bin/ffmpeg' if os.path.exists('/opt/bin/ffmpeg') else 'ffmpeg'
        print(f"Using FFmpeg at: {ffmpeg_path}")
        
        # Get current week's date range
        today = datetime.now()
        week_start = today - timedelta(days=today.weekday())
        week_end = week_start + timedelta(days=6)
        
        print(f"Processing videos for week: {week_start.strftime('%Y-%m-%d')} to {week_end.strftime('%Y-%m-%d')}")
        
        # Get all groups from S3
        groups = get_groups_from_s3()
        print(f"Found {len(groups)} groups to process")
        
        results = []
        
        for group_id in groups:
            try:
                print(f"Processing group: {group_id}")
                result = process_group_videos(group_id, week_start, week_end, ffmpeg_path)
                results.append(result)
            except Exception as e:
                print(f"❌ Error processing group {group_id}: {str(e)}")
                results.append({
                    'group_id': group_id,
                    'status': 'error',
                    'error': str(e)
                })
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Video compilation completed',
                'results': results,
                'processed_groups': len(results)
            })
        }
        
    except Exception as e:
        print(f"❌ Lambda execution failed: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': str(e)
            })
        }

def get_groups_from_s3() -> List[str]:
    """
    Get all group IDs from S3
    """
    try:
        response = s3_client.list_objects_v2(
            Bucket=S3_BUCKET,
            Prefix='groups/',
            Delimiter='/'
        )
        
        groups = []
        if 'CommonPrefixes' in response:
            for prefix in response['CommonPrefixes']:
                group_id = prefix['Prefix'].replace('groups/', '').replace('/', '')
                groups.append(group_id)
        
        return groups
    except Exception as e:
        print(f"Error getting groups from S3: {e}")
        return []

def process_group_videos(group_id: str, week_start: datetime, week_end: datetime, ffmpeg_path: str) -> Dict[str, Any]:
    """
    Process videos for a specific group
    """
    try:
        # Get videos for this group and week
        videos = get_group_videos(group_id, week_start, week_end)
        
        if not videos:
            print(f"No videos found for group {group_id}")
            return {
                'group_id': group_id,
                'status': 'no_videos',
                'message': 'No videos found for this week'
            }
        
        print(f"Found {len(videos)} videos for group {group_id}")
        
        # Create compilation
        compilation_url = create_video_compilation(group_id, videos, week_start, week_end, ffmpeg_path)
        
        return {
            'group_id': group_id,
            'status': 'success',
            'compilation_url': compilation_url,
            'video_count': len(videos)
        }
        
    except Exception as e:
        print(f"Error processing group {group_id}: {e}")
        raise

def get_group_videos(group_id: str, week_start: datetime, week_end: datetime) -> List[Dict[str, Any]]:
    """
    Get videos for a specific group within the date range
    """
    try:
        # List videos in the group's folder
        response = s3_client.list_objects_v2(
            Bucket=S3_BUCKET,
            Prefix=f'groups/{group_id}/videos/'
        )
        
        videos = []
        if 'Contents' in response:
            for obj in response['Contents']:
                # Check if video is within the week
                video_date = obj['LastModified'].replace(tzinfo=None)
                if week_start <= video_date <= week_end:
                    videos.append({
                        'key': obj['Key'],
                        'size': obj['Size'],
                        'last_modified': video_date
                    })
        
        return videos
    except Exception as e:
        print(f"Error getting videos for group {group_id}: {e}")
        return []

def create_video_compilation(group_id: str, videos: List[Dict[str, Any]], week_start: datetime, week_end: datetime, ffmpeg_path: str) -> str:
    """
    Create a video compilation from the group's videos
    """
    try:
        with tempfile.TemporaryDirectory() as temp_dir:
            print(f"Creating compilation in temporary directory: {temp_dir}")
            
            # Download videos
            video_files = []
            for i, video in enumerate(videos):
                video_path = os.path.join(temp_dir, f"video_{i}.mp4")
                s3_client.download_file(S3_BUCKET, video['key'], video_path)
                video_files.append(video_path)
                print(f"Downloaded: {video['key']}")
            
            # Create intro card
            intro_path = create_intro_card(group_id, week_start, week_end, temp_dir, ffmpeg_path)
            
            # Create outro card
            outro_path = create_outro_card(temp_dir, ffmpeg_path)
            
            # Create compilation
            compilation_path = os.path.join(temp_dir, f"compilation_{group_id}_{week_start.strftime('%Y%m%d')}.mp4")
            
            # Build FFmpeg command
            cmd = [ffmpeg_path, '-y']  # -y to overwrite output
            
            # Add intro
            if intro_path:
                cmd.extend(['-i', intro_path])
            
            # Add videos
            for video_file in video_files:
                cmd.extend(['-i', video_file])
            
            # Add outro
            if outro_path:
                cmd.extend(['-i', outro_path])
            
            # Create filter complex for concatenation
            filter_parts = []
            input_count = 0
            
            if intro_path:
                filter_parts.append(f"[{input_count}]scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2[intro]")
                input_count += 1
            
            for i in range(len(video_files)):
                filter_parts.append(f"[{input_count}]scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2[video{i}]")
                input_count += 1
            
            if outro_path:
                filter_parts.append(f"[{input_count}]scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2[outro]")
                input_count += 1
            
            # Concatenate all parts
            concat_parts = []
            if intro_path:
                concat_parts.append("[intro]")
            for i in range(len(video_files)):
                concat_parts.append(f"[video{i}]")
            if outro_path:
                concat_parts.append("[outro]")
            
            filter_complex = ';'.join(filter_parts) + f";{''.join(concat_parts)}concat=n={len(concat_parts)}:v=1:a=1[outv][outa]"
            
            cmd.extend([
                '-filter_complex', filter_complex,
                '-map', '[outv]',
                '-map', '[outa]',
                '-c:v', 'libx264',
                '-c:a', 'aac',
                '-preset', 'fast',
                '-crf', '23',
                compilation_path
            ])
            
            print(f"Running FFmpeg command: {' '.join(cmd)}")
            
            # Execute FFmpeg
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode != 0:
                print(f"FFmpeg error: {result.stderr}")
                raise Exception(f"FFmpeg failed: {result.stderr}")
            
            print("✅ Video compilation created successfully")
            
            # Upload to S3
            compilation_key = f"compilations/{group_id}/{week_start.strftime('%Y%m%d')}_compilation.mp4"
            s3_client.upload_file(compilation_path, S3_BUCKET, compilation_key)
            
            # Generate presigned URL
            compilation_url = s3_client.generate_presigned_url(
                'get_object',
                Params={'Bucket': S3_BUCKET, 'Key': compilation_key},
                ExpiresIn=3600  # 1 hour
            )
            
            print(f"✅ Compilation uploaded to S3: {compilation_key}")
            return compilation_url
            
    except Exception as e:
        print(f"Error creating video compilation: {e}")
        raise

def create_intro_card(group_id: str, week_start: datetime, week_end: datetime, temp_dir: str, ffmpeg_path: str) -> str:
    """
    Create an intro card for the compilation
    """
    try:
        intro_path = os.path.join(temp_dir, "intro.mp4")
        
        # Create intro text
        intro_text = f"Week of {week_start.strftime('%B %d, %Y')}"
        
        # Create intro video using FFmpeg
        cmd = [
            ffmpeg_path, '-y',
            '-f', 'lavfi',
            '-i', f'color=c=black:size=1280x720:duration=3',
            '-vf', f'drawtext=text="{intro_text}":fontcolor=white:fontsize=48:x=(w-text_w)/2:y=(h-text_h)/2',
            '-c:v', 'libx264',
            '-preset', 'fast',
            intro_path
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode == 0:
            print("✅ Intro card created")
            return intro_path
        else:
            print(f"⚠️ Intro card creation failed: {result.stderr}")
            return None
            
    except Exception as e:
        print(f"Error creating intro card: {e}")
        return None

def create_outro_card(temp_dir: str, ffmpeg_path: str) -> str:
    """
    Create an outro card for the compilation
    """
    try:
        outro_path = os.path.join(temp_dir, "outro.mp4")
        
        # Create outro text
        outro_text = "Created with Weave"
        
        # Create outro video using FFmpeg
        cmd = [
            ffmpeg_path, '-y',
            '-f', 'lavfi',
            '-i', f'color=c=black:size=1280x720:duration=2',
            '-vf', f'drawtext=text="{outro_text}":fontcolor=white:fontsize=36:x=(w-text_w)/2:y=(h-text_h)/2',
            '-c:v', 'libx264',
            '-preset', 'fast',
            outro_path
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode == 0:
            print("✅ Outro card created")
            return outro_path
        else:
            print(f"⚠️ Outro card creation failed: {result.stderr}")
            return None
            
    except Exception as e:
        print(f"Error creating outro card: {e}")
        return None
